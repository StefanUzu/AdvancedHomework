package OOP._01_Abstraction_Exercise._04_Traffic_Lights;

public enum Lights {
    RED,
    GREEN,
    YELLOW;
}
