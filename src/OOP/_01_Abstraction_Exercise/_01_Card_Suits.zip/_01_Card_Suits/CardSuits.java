package OOP._01_Abstraction_Exercise._01_Card_Suits;
public enum CardSuits {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;
}


